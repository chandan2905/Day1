﻿using Ado_project.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ado_project
{
    public partial class Update : Form
    {
        EmployeeLogic ob;
        public Update()
        {
            InitializeComponent();
            ob = new EmployeeLogic();
        }

        private void Update_Load(object sender, EventArgs e)
        {
            label2.Visible = false;
            label3.Visible = false;
            tbempname.Visible = false;
            tbsalary.Visible = false;
            btnupdate.Visible = false;

        }

        private void btncheck_Click(object sender, EventArgs e)
        {
            int i;
            i = Convert.ToInt32(tbempid.Text);
            Employee e1 = ob.search2(i);
            if(e1==null)
            {
                MessageBox.Show("Enter the valid empid as this does not exist!!");
            }
            else
            {
                label2.Visible = true;
                label3.Visible = true;
                tbempname.Visible = true;
                tbsalary.Visible = true;
                btnupdate.Visible = true;
            }
        }
        private void btnupdate_Click(object sender, EventArgs e)
        {
            Employee e1 = new Employee();
            e1.empid = Convert.ToInt32(tbempid.Text);
            e1.empname = tbempname.Text.ToString();
            e1.salary = Convert.ToInt32(tbsalary.Text);
            ob.update(e1);
            tbempid.Text = "";
            tbempname.Text = "";
            tbsalary.Text = "";

            dataGridView1.DataSource = ob.getAllEmployeeInfo();
            label2.Visible = false;
            label3.Visible = false;
            tbempname.Visible = false;
            tbsalary.Visible = false;
            btnupdate.Visible = false;
            btncheck.Visible = true;
        }
    }
}
