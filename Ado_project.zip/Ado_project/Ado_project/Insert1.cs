﻿using Ado_project.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ado_project
{
    public partial class Insert1 : Form
    {
        EmployeeLogic ob;
        public Insert1()
        {
            InitializeComponent();
            ob = new EmployeeLogic();
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            Employee e1 = new Employee();
            e1.empid = Convert.ToInt32(tbempid.Text);
            e1.empname = tbempname.Text.ToString();
            e1.dob = tbdob.Text.ToString();
            e1.phone = tbphone.Text.ToString();
            e1.salary = Convert.ToInt32(tbsalary.Text);
            e1.email = tbemail.Text.ToString();
            e1.deptid = Convert.ToInt32(tbdeptid.Text);
            string msg = ob.addSp(e1);
            MessageBox.Show(msg);
            dataGridView1.DataSource = ob.getAllEmployeeInfo();
            tbempid.Text = "";
            tbempname.Text = "";
            tbdob.Text = "";
            tbphone.Text = "";
            tbsalary.Text = "";
            tbemail.Text = "";
            tbdeptid.Text = "";
        }
    }
}
