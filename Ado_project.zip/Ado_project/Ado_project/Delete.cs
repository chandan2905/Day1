﻿using Ado_project.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ado_project
{
    public partial class Delete : Form
    {
        EmployeeLogic ob;
        public Delete()
        {
            InitializeComponent();
            ob = new EmployeeLogic();
        }

        private void Delete_Load(object sender, EventArgs e)
        {
            
            btndelete.Visible = false;
        }

        private void btncheck_Click(object sender, EventArgs e)
        {
            int i;
            i = Convert.ToInt32(tbdelete.Text);
            Employee e1 = ob.search3(i);
            if (e1 == null)
            {
                MessageBox.Show("Enter the valid empid as this does not exist!!");
            }
            else
            {
                btndelete.Visible = true;
            }

        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(tbdelete.Text);
            string msg = ob.delete(id);
            MessageBox.Show(msg);
            tbdelete.Text = "";
            dataGridView1.DataSource = ob.getAllEmployeeInfo();


        }
    }
}
