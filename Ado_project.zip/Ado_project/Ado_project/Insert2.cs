﻿using Ado_project.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ado_project
{
    public partial class Insert2 : Form
    {
        DepartmentLogic ob;
        public Insert2()
        {
            InitializeComponent();
            ob = new DepartmentLogic();
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            Department d1 = new Department();
            d1.deptid = Convert.ToInt32(tbdeptid.Text);
            d1.deptname = tbdeptname.Text.ToString();
            d1.dlocation = tbdlocation.Text.ToString();
            d1.managerid = Convert.ToInt32(tbmanagerid.Text);
            
            string msg = ob.addSp(d1);
            MessageBox.Show(msg);
            dataGridView1.DataSource = ob.getAllDepartment();
            tbdeptid.Text = "";
            tbdeptname.Text = "";
            tbdlocation.Text = "";
            tbmanagerid.Text = "";
        }
    }
}
