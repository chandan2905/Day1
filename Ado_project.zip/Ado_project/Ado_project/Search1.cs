﻿using Ado_project.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ado_project
{
    public partial class Search1 : Form
    {
        EmployeeLogic ob;
        public Search1()
        {
            InitializeComponent();
            ob = new EmployeeLogic();
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {

            dataGridView1.Visible = false;
            string name;
            name = tbsearch.Text.ToString();
            Employee e2 = ob.searchName(name);
            if (e2 == null)
            {
                MessageBox.Show("The record is not present!!");
            }
            else
            {
                List<Employee> li = new List<Employee>();
                li.Add(e2);
                dataGridView1.Visible = true;
                dataGridView1.DataSource = li;
                MessageBox.Show("The record is present!!");
                tbsearch.Text = "";
            }
        }
        private void Search1_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
        }
    }
}
