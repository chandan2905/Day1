﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace Ado_project.Model
{
    class DepartmentLogic
    {
        private string conStr = ConfigurationManager.ConnectionStrings["db"].ConnectionString;

        public List<Department> getAllDepartment()
        {
            List<Department> li = new List<Department>();
            SqlConnection conn = new SqlConnection(conStr);
            string sql = "select * from Department";
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Department d = new Department();
                    d.deptid = Convert.ToInt32(reader.GetValue(0));
                    d.deptname = reader.GetValue(1).ToString();
                    d.dlocation = reader.GetValue(2).ToString();
                    d.managerid = Convert.ToInt32(reader.GetValue(3));

                    li.Add(d);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("CAN NOT CONNECT TO DATABASE!!");

            }
            finally
            {
                conn.Close();
            }
            return li;
        }


        public string addSp(Department d)
        {
            string msg = null;
            string sql = "spinsertdepartment";
            SqlConnection conn = new SqlConnection(conStr);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@deptid", SqlDbType.Int).Value = d.deptid;
                cmd.Parameters.Add("@deptname", SqlDbType.VarChar, 50).Value = d.deptname;
                cmd.Parameters.Add("@dlocation", SqlDbType.VarChar,50).Value = d.dlocation;
                cmd.Parameters.Add("@managerid", SqlDbType.Int).Value = d.managerid;
                
                cmd.ExecuteNonQuery();
                msg = "Data inserted successfully!!";
            }
            catch (Exception)
            {
                msg = "Could not insert the data!!";
            }
            finally
            {
                conn.Close();

            }
            return msg;
        }
    }
}
