﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace Ado_project.Model
{
    class EmployeeLogic
    {
        private string conStr = ConfigurationManager.ConnectionStrings["db"].ConnectionString;

        public List<Employee> getAllEmployeeInfo()
        {
            List<Employee> li = new List<Employee>();
            SqlConnection conn = new SqlConnection(conStr);
            string sql = "select * from employee";
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while(reader.Read())
                {
                    Employee e = new Employee();
                    e.empid = Convert.ToInt32(reader.GetValue(0));
                    e.empname = reader.GetValue(1).ToString();
                    e.dob = reader.GetValue(2).ToString();
                    e.phone = reader.GetValue(3).ToString();
                    e.salary = Convert.ToInt32(reader.GetValue(4));
                    e.email = reader.GetValue(5).ToString();
                    e.deptid = Convert.ToInt32(reader.GetValue(6));
                    li.Add(e);
                }
            }
            catch(Exception)
            {
                MessageBox.Show("CAN NOT CONNECT TO DATABASE!!");

            }
            finally
            {
                conn.Close();
            }
            return li;
        }
        public string addSp(Employee e)
        {
            string msg = null;
            string sql = "spinsertemployee";
            SqlConnection conn = new SqlConnection(conStr);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@empid", SqlDbType.Int).Value = e.empid;
                cmd.Parameters.Add("@empname", SqlDbType.VarChar, 50).Value = e.empname;
                cmd.Parameters.Add("@dob", SqlDbType.Date).Value = e.dob;
                cmd.Parameters.Add("@phone", SqlDbType.VarChar,50).Value = e.phone;
                cmd.Parameters.Add("@salary", SqlDbType.Int).Value = e.salary;
                cmd.Parameters.Add("@email", SqlDbType.VarChar,50).Value = e.email;
                cmd.Parameters.Add("@deptid", SqlDbType.Int).Value = e.deptid;
                cmd.ExecuteNonQuery();
                msg = "Data inserted successfully!!";
            }
            catch(Exception)
            {
                msg = "Could not insert the data!!";
            }
            finally
            {
                conn.Close();

            }
            return msg;
        }
        public Employee searchName(string name)
        {
            string sql = "select * from employee where empname=" + name;
            SqlConnection conn = new SqlConnection(conStr);
            Employee ob = new Employee();
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader sqr = cmd.ExecuteReader();
                if (sqr.HasRows)
                {
                    while (sqr.Read())
                    {
                        ob.empid = Convert.ToInt32(sqr.GetValue(0));
                        ob.empname = sqr.GetValue(1).ToString();
                        ob.dob = sqr.GetValue(2).ToString();
                        ob.phone = sqr.GetValue(3).ToString();
                        ob.salary = Convert.ToInt32(sqr.GetValue(4));
                        ob.email = sqr.GetValue(5).ToString();
                        ob.deptid = Convert.ToInt32(sqr.GetValue(6));

                    }
                }
                else
                {
                    ob = null;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Record not fond for that name!!");
            }
            finally
            {
                conn.Close();
            }
            return ob;
        }

        public Employee searchSal(int sal)
        {
            string sql = "select * from employee where salary=" + sal;
            SqlConnection conn = new SqlConnection(conStr);
            Employee ob = new Employee();
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader sqr = cmd.ExecuteReader();
                if (sqr.HasRows)
                {
                    while (sqr.Read())
                    {
                        ob.empid = Convert.ToInt32(sqr.GetValue(0));
                        ob.empname = sqr.GetValue(1).ToString();
                        ob.dob = sqr.GetValue(2).ToString();
                        ob.phone = sqr.GetValue(3).ToString();
                        ob.salary = Convert.ToInt32(sqr.GetValue(4));
                        ob.email = sqr.GetValue(5).ToString();
                        ob.deptid = Convert.ToInt32(sqr.GetValue(6));

                    }
                }
                else
                {
                    ob = null;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Record not fond for that salary!!");
            }
            finally
            {
                conn.Close();
            }
            return ob;
        }

        public Employee search2(int id)
        {
            string sql = "select * from Employee where empid=" + id;
            SqlConnection conn = new SqlConnection(conStr);
            Employee ob = new Employee();
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader sqr = cmd.ExecuteReader();
                if (sqr.HasRows)
                {
                    while (sqr.Read())
                    {
                        ob.empid = Convert.ToInt32(sqr.GetValue(0));
                        ob.empname = sqr.GetValue(1).ToString();
                        ob.salary = Convert.ToInt32(sqr.GetValue(4));
                    }
                }
                else
                {
                    ob = null;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Record not fond for that empid!!");
            }
            finally
            {
                conn.Close();
            }
            return ob;
        }
        public void update(Employee e)
        {
            string msg = null;
            string sql = "spupdate";
            SqlConnection conn = new SqlConnection(conStr);

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@empid", SqlDbType.Int).Value = e.empid;
                cmd.Parameters.Add("@empname", SqlDbType.VarChar, 50).Value = e.empname;
                cmd.Parameters.Add("@salary", SqlDbType.Int).Value = e.salary;
                cmd.ExecuteNonQuery();
                msg = "Data updated successfully!!";
                MessageBox.Show(msg);

            }
            catch (Exception)
            {
                msg = "Could not update the data!!";
                MessageBox.Show(msg);

            }
            finally
            {
                conn.Close();
            }
        }

        public Employee search3(int id)
        {
            string sql = "select * from Employee where empid=" + id;
            SqlConnection conn = new SqlConnection(conStr);
            Employee ob = new Employee();
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader sqr = cmd.ExecuteReader();
                if (sqr.HasRows)
                {
                    while (sqr.Read())
                    {
                        ob.empid = Convert.ToInt32(sqr.GetValue(0));
                        
                    }
                }
                else
                {
                    ob = null;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Record not fond for that empid!!");
            }
            finally
            {
                conn.Close();
            }
            return ob;
        }
        public string delete(int id)
        {
            string msg = null;
            string sql = "spdelete";
            SqlConnection conn = new SqlConnection(conStr);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@empid", SqlDbType.Int).Value = id;

                cmd.ExecuteNonQuery();
                msg = "DATA DELETED...";

            }
            catch(Exception)
            {
                msg = "Sorry could not delete the data!!";
            }
            finally
            {
                conn.Close();
            }

            return msg;
        }

    }
}
