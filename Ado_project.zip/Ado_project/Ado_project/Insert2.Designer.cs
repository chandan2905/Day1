﻿namespace Ado_project
{
    partial class Insert2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbdeptid = new System.Windows.Forms.TextBox();
            this.tbdeptname = new System.Windows.Forms.TextBox();
            this.tbdlocation = new System.Windows.Forms.TextBox();
            this.tbmanagerid = new System.Windows.Forms.TextBox();
            this.btninsert = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(74, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "DEPTID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(74, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "DEPTNAME";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(74, 138);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "DLOCATION";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(74, 189);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "MANAGERID";
            // 
            // tbdeptid
            // 
            this.tbdeptid.Location = new System.Drawing.Point(208, 40);
            this.tbdeptid.Name = "tbdeptid";
            this.tbdeptid.Size = new System.Drawing.Size(100, 22);
            this.tbdeptid.TabIndex = 4;
            // 
            // tbdeptname
            // 
            this.tbdeptname.Location = new System.Drawing.Point(208, 89);
            this.tbdeptname.Name = "tbdeptname";
            this.tbdeptname.Size = new System.Drawing.Size(100, 22);
            this.tbdeptname.TabIndex = 5;
            // 
            // tbdlocation
            // 
            this.tbdlocation.Location = new System.Drawing.Point(208, 138);
            this.tbdlocation.Name = "tbdlocation";
            this.tbdlocation.Size = new System.Drawing.Size(100, 22);
            this.tbdlocation.TabIndex = 6;
            // 
            // tbmanagerid
            // 
            this.tbmanagerid.Location = new System.Drawing.Point(208, 189);
            this.tbmanagerid.Name = "tbmanagerid";
            this.tbmanagerid.Size = new System.Drawing.Size(100, 22);
            this.tbmanagerid.TabIndex = 7;
            // 
            // btninsert
            // 
            this.btninsert.Location = new System.Drawing.Point(417, 152);
            this.btninsert.Name = "btninsert";
            this.btninsert.Size = new System.Drawing.Size(114, 54);
            this.btninsert.TabIndex = 8;
            this.btninsert.Text = "INSERT DATA";
            this.btninsert.UseVisualStyleBackColor = true;
            this.btninsert.Click += new System.EventHandler(this.btninsert_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(36, 237);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(660, 185);
            this.dataGridView1.TabIndex = 9;
            // 
            // Insert2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btninsert);
            this.Controls.Add(this.tbmanagerid);
            this.Controls.Add(this.tbdlocation);
            this.Controls.Add(this.tbdeptname);
            this.Controls.Add(this.tbdeptid);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Insert2";
            this.Text = "Insert2";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbdeptid;
        private System.Windows.Forms.TextBox tbdeptname;
        private System.Windows.Forms.TextBox tbdlocation;
        private System.Windows.Forms.TextBox tbmanagerid;
        private System.Windows.Forms.Button btninsert;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}